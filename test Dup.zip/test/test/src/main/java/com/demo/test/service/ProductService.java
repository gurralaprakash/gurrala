package com.demo.test.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.test.model.Product;
import com.demo.test.repository.ProductRepository;

@Service
public class ProductService {
	@Autowired
	private ProductRepository productRepository;
	
	public Product saveProduct(Product product) {
		return productRepository.save(product);
	}
	
	public List<Product> saveProducts(List<Product> products){
		return productRepository.saveAll(products);
	}
	
	public List<Product> readProducts(){
		return productRepository.findAll();
	}
	
	public Product reaProduct(int id) {
		return productRepository.findById(id).orElse(null);
	}
	
	public Product readProduct(String name) {
		return productRepository.findByName(name);
	}
	
	public String deletProduct(int id) {
		productRepository.deleteById(id);
		return "product removed " +id;
	}
	
	public Product updateProduct(Product product) {
		Product existedProduct=productRepository.findById(product.getId()).orElse(null);
		existedProduct.setName(product.getName());
		existedProduct.setPrice(product.getPrice());
		existedProduct.setQuantity(product.getQuantity());
		return productRepository.save(existedProduct);
	}
	
}
