package com.demo.test.controller;

import java.util.List;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.demo.test.model.Employee;
import com.demo.test.servvice.EmployeeNotFoundException;
import com.demo.test.servvice.EmployeeService;
import com.fasterxml.jackson.core.format.InputAccessor;

@RestController
public class EmployeeController {
	@Autowired
	private EmployeeService employeeService;
	
	@PostMapping("/save")
	public Employee employee(@RequestBody Employee employee) {
		return employeeService.saveEmployee(employee);
	}
	@PostMapping("/saveall")
	public List<Employee> saveAll(List<Employee> employees){
		return employeeService.employees();
	}
	
	
	@GetMapping("/gettest")
	public List<Employee> employees(){
		return employeeService.employees();
		
	}
	/*
	 * @PostMapping("/getpost") public ResponseEntity<List<Employee>>
	 * getproductbyId(@RequestBody ){ return new
	 * ResponseEntity<List<Employee>>(employeeService.getEmployees(input.getIds()),
	 * HttpStatus.OK); }
	 */
	
	/*
	 * @PostMapping("/showCitiesEnding") public Integer findCitiesNameEndsWith(Model
	 * model, @RequestParam Integer ids) { return ids;
	 * 
	 * }
	 */
	
	 @PostMapping("/{id}")
	    public Employee getById(@PathVariable(required = true) int id) throws EmployeeNotFoundException {
	        return employeeService.getEmployeeByID(id);
	    }
	
	
}
