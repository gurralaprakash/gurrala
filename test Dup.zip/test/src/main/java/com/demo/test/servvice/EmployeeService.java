package com.demo.test.servvice;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.demo.test.model.Employee;
import com.demo.test.repository.EmployeeRepository;

@Service
public class EmployeeService {
	@Autowired
	private EmployeeRepository employeeRepository;
	
	public Employee saveEmployee(Employee employee) {
		return employeeRepository.save(employee);
	}

	public List<Employee> saveEmployees(List<Employee> employees){
		return employeeRepository.findAll();		
	}
	
	
	public List<Employee> employees(){
		return employeeRepository.findAll(); 
		
	}
	/*
	 * public List<Employee> getEmployees(List<Integer> ids){ return
	 * employeeRepository.finEmployeesbyId(ids); }
	 */
	
	public Employee getEmployeeByID(int id) throws EmployeeNotFoundException {
		Optional<Employee> optional=employeeRepository.findById(id);
		return optional.orElseThrow(()->new EmployeeNotFoundException("Couldn't find a employee with id: " + id));
		}
	
}
